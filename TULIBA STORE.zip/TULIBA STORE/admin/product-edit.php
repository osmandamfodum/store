<?php require_once('header.php'); ?>
<?php
$conn= mysqli_connect("localhost","root","","tuliba_store");

if(isset($_POST['form1'])){
	        $tcat_id = $_POST['tcat_id'];
			$p_name = $_POST['p_name'];
            $p_current_price = $_POST['p_current_price'];
			$p_qty = $_POST['p_qty'];
			$file = $_FILES['p_featured_photo']['name'];
			$p_short_description = $_POST['p_short_description'];
			$p_is_featured = $_POST['p_is_featured'];
			$p_is_active = $_POST['p_is_active'];
		    $ecat_id = $_POST['ecat_id'];
	
	$query ="UPDATE  tbl_product SET p_name='$p_name', p_current_price='$p_current_price'p_qty='$p_qty'p_featured_photo='$p_featured_photo'p_short_description='$p_short_description'p_is_featured='$p_is_featured'p_is_active='$p_is_active' WHERE tcat_id='$tcat_id'";
		
	$res = mysqli_query($conn,$query);
	if($res){
	header('location:top-category.php');
	}
	
}

	?>
	
	
<section class="content-header">
	<div class="content-header-left">
		<h1>update Product</h1>
	</div>
	<div class="content-header-right">
		<a href="products.php" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>


<section class="content">

	<div class="row">
		<div class="col-md-12">
		
		
			
		
		
		
		
		
		
		
		
		<?php
									$sql = "SELECT * FROM tbl_product ";
          $res = mysqli_query($conn,  $sql);

          if (mysqli_num_rows($res) > 0) {
          	while ($tbl_product  = mysqli_fetch_assoc($res)) {  ?>
			


			<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">

				<div class="box box-info">
					<div class="box-body">
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Top Level Category Name <span>*</span></label>
							<div class="col-sm-4">
								<select name="tcat_id" class="form-control select2 top-cat">
									<option value="">Select Top Level Category</option>
									<?php
									$sql = "SELECT * FROM tbl_top_category ORDER BY tcat_name ASC";
          $res = mysqli_query($conn,  $sql);

          if (mysqli_num_rows($res) > 0) {
          	while ($tbl_product  = mysqli_fetch_assoc($res)) {  ?>
			
			
										<option value="<?=$tbl_product ['tcat_id']?>"><?=$tbl_product ['tcat_name']?></option>
										<?php
									}
									?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Mid Level Category Name <span>*</span></label>
							<div class="col-sm-4">
								<select name="mcat_id" class="form-control select2 mid-cat">
									<option value="">Select Mid Level Category</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">End Level Category Name <span>*</span></label>
							<div class="col-sm-4">
								<select name="ecat_id" class="form-control select2 end-cat">
									<option value="">Select End Level Category</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Product Name <span>*</span></label>
							<div class="col-sm-4">
								<input type="text" name="p_name" class="form-control">
							</div>
						</div>	
						
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Price <span>*</span><br><span style="font-size:10px;font-weight:normal;">(SDG)</span></label>
							<div class="col-sm-4">
								<input type="text" name="p_current_price" class="form-control">
							</div>
						</div>	
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Quantity <span>*</span></label>
							<div class="col-sm-4">
								<input type="text" name="p_qty" class="form-control">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Select Size</label>
							<div class="col-sm-4">
								<select name="size[]" class="form-control select2" multiple="multiple">
								
								
								<?php
									$sql = "SELECT * FROM tbl_size  ORDER BY size_id ASC";
          $res = mysqli_query($conn,  $sql);

          if (mysqli_num_rows($res) > 0) {
          	while ($tbl_product  = mysqli_fetch_assoc($res)) {  ?>
								
										<option value="<?=$tbl_product ['size_id']?>"><?=$tbl_product ['size_name']?></option>
										<?php
									}
									?>
								</select>
							</div>
						</div>
						
					
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Short Description <span>*</span></label>
							<div class="col-sm-4">
								<input type="text" name="p_short_description" class="form-control">
							</div>
						</div>	
						
						
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Featured Photo <span>*</span></label>
							<div class="col-sm-4" style="padding-top:4px;">
								<input type="file" name="p_featured_photo">
							</div>
						</div>
						
						
						
						
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Is Featured?</label>
							<div class="col-sm-8">
								<select name="p_is_featured" class="form-control" style="width:auto;">
									<option value="0">No</option>
									<option value="1">Yes</option>
								</select> 
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Is Active?</label>
							<div class="col-sm-8">
								<select name="p_is_active" class="form-control" style="width:auto;">
									<option value="0">No</option>
									<option value="1">Yes</option>
								</select> 
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label"></label>
							<div class="col-sm-6">
								<button type="submit" class="btn btn-success pull-left" name="form1">Add Product</button>
							</div>
						</div>
					</div>
				</div>

			</form>


		</div>
	</div>

</section>
         <?php
                    }
			}
		  
		  
			}
		  }
		  
                    ?>
<?php require_once('footer.php'); ?>